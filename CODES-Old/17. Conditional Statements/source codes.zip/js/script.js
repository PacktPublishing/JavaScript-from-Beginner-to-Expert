/*
 *  CONDITIONAL statements  
 */

var a = 2,
    b = 3;
    
if (a > b)
    alert(a + " is bigger than " + b);   
else if (a < b)
{
    alert(a + " is lower than " + b);
    alert("test");
}
else
    alert("a == b");





