/*
    Math.round() - rounds the number to the nerest integer
    Math.ceil() - ceiling is up - so you round always up
    Math.floor() - floor is down - so you round always down
    toFixed(howManyNumbersAfterTheDot);

    Math.abs() - absolute value (always positive)
    Math.pow(x,y) - x to the power of y

    parseInt
    parseFloat("2.567hahaasfasf");
    typeof

    Math.random(); - returns random value from 0 to 1
    
 */

window.onload = function()
{
    var info = document.getElementById("info");
    var x = parseFloat("3.1246kasfjk");
    
    info.innerHTML = Math.random();
    
    
    
};









