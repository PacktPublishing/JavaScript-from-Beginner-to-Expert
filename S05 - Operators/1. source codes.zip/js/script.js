/*
 * OPERATOR - characters used to operate on variables
 * 
 *  ARITHMETIC operators
 *      +   adding numbers and merging strings (
 *      -   subtraction
 *      *   multiplying
 *      /   dividing
 *      
 *      %  the remainder of the division (mod operator) % 5
 *      
 *      =   assigning value
 *      +=  
 *      -=
 *      /=
 *      *=
 *      %=
 *      
 *      
 *      ++   incrementation - increase the value by 1
 *      --   decrementation - decrease the value by 1
 *      
 *      x++ POST incrementation
 *      x-- POST DECREMENTATION
 *      
 *      ++x PRE INCREMENTATION
 *      --x PRE DECREMENTATION
 */

var x = 1;


//x /= 2; //x = x + 2;


alert(++x);
