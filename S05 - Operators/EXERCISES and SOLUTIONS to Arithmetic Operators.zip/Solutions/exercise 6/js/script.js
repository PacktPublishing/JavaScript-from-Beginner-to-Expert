var firstNumber = 24;
var secondNumber = 15;

var divisionResult = firstNumber / secondNumber;

alert("Division result: " + divisionResult);
