var firstNumber = 24;
var secondNumber = 15;

var substractionResult = firstNumber - secondNumber;

alert("Subtraction result: " + substractionResult);
