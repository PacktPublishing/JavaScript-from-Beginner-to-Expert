/*
 * RELATIONAL OPERATORS (comparison operators)
 * 
 * ==
 * 
 * === - IDENTICAL, variables must be the same type too
 * 
 * !=
 * 
 * >
 * <
 * >=
 * <=
 * 
 */

var a = 7,
    b = 5;
    
alert(a < 5);

