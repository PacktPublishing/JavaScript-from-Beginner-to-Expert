/* 
  const - constant - unchangeable after setting first value
  f2
*/

const PI = 3.14159;
const MAXIMUM_SCORE = 400;
const VAT_GB = 23;
const MAXIMUM_POST_LENGTH = 200;

PI = 3;

alert(PI)














































































 