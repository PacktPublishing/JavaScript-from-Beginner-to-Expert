

function PWAInstallButton() {

    return (
        <button>
            Install PWA app
        </button>
    );
}

export default PWAInstallButton