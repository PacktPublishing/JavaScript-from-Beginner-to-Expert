export default function Button()
{
    return "Button";
}
export function Skill()
{
    return "Skill";
}
export function Another()
{

}
function AnotherFunctions()
{
    
}