function Navigation()
{
    return "Navigation";
}

export default Navigation;