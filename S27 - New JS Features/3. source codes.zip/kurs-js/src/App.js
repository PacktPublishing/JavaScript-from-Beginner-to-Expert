import Button, {Skill} from "../Components/Button.js"
import Header from "../Header.js"
import Navigation from "../Navigation.js"


function App()
{
    console.log(Button())
    console.log(Skill())
    console.log(Header())
    console.log(Navigation())
}

App()