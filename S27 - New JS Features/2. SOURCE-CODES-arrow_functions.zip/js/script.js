/*
arrow function 
=>
   map - assign (map) a new value to each array element
   based on the function passed as an argument, return new array
   filter - filter the array, return a new array with elements that 
   meet the condition from the function
  
*/
function multiplyBy(x)
{
  return x * 2;
}

x => x * 3;

let numbers = [1, 2, 3, 4, 5];
// numbers = [2, 4, 6, 8, 10];

// for (let i = 0; i < numbers.length; i++)
// {
//     numbers[i] = multiplyBy(numbers[i]);
// }

// alert(numbers);


let newNumbers = numbers.map(x => x * 2).filter(x => x > 5);
let newNumbers2 = numbers.map(x => x * 5).filter(x => x > 10);

alert(newNumbers2)

