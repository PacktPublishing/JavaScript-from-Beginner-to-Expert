/* 
  Nullish coalescing operator (??)

  coalescing - process of merging (connecting) two into one

  undefined 
  
  or

  null 

  then connect into

  ...

  ??
  
  (expressionOnLeft)  ?? (expressonOnRight)
*/

let userName = null;

//userName = userName ?? "Anonymous";

userName ??= "Anonymous";

alert(userName);














































































 