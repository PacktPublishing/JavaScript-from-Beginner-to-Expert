import './App.css'
import GoldClicker from './components/GoldClicker';

function App() 
{           

    return (
      <> 
        <GoldClicker />
      </>     
    );
}

export default App
