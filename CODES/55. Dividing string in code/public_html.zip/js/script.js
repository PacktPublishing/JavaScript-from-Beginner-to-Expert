/*
   
 */

window.onload = function()
{
   var info = document.getElementById("info");
   
   var tmp = "I'am said: \"ahahaha\" A very long text should be divided into many lines in a code \
              so the code is easier to read... but there is a small problem";
   

   
   
   info.innerHTML = tmp;
};






