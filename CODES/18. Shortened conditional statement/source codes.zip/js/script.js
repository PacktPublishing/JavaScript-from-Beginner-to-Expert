/*
 *
 *  Shorthened conditional statement called operator ? :
 *  
 *  (expression) ? return_if_the_expression_is_true : return_if_the_expression_is_false; 
 *  
 *  
 */

var x = 4;
/*var isEven;

if (x % 2 === 0)
    isEven = true;
else
    isEven = false;

*/


alert((x % 2 === 0) ? "the value is even" : "the value is not even");