import './App.css'
import GoldMiner from './components/GoldMiner'

function App()  //THIS IS COMPONENT 
{
    return (
      <>
        <GoldMiner />
      </>
    );
}

export default App
