/*
  STYLES in DOM                        
 */

var courses = document.querySelectorAll("#programmingCourses li");


for (var index in courses)
{
    courses[index].style.color = "red";
}


