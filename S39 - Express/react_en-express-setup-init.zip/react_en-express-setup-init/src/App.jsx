import './App.css'
import { ThemeProvider } from './contexts/ThemeContext';

function App()  //THIS IS COMPONENT 
{
    
    return (
      <>
        <ThemeProvider>
        
       
          
        </ThemeProvider>        
      </>
    );
}

export default App
